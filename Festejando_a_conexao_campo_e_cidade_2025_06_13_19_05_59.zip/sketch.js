let inputSugestao, botaoEnviar;
let sugestoes = [];

function setup() {
  noCanvas(); // Só usaremos elementos HTML

  createElement('h1', '🌾 Festejando a conexão entre o campo e a cidade');

  // Seção sobre agricultura
  createElement('h2', '🚜 O trabalho agrícola e seu dia a dia');
  createP('A relação entre o campo e a cidade é essencial para o desenvolvimento social e econômico. O campo fornece alimentos para a cidade, e a cidade oferece o mercado consumidor.');

  // Seção sobre crescimento urbano
  createElement('h2', '🌆 Como funciona o crescimento urbano');
  createP('O crescimento urbano traz desafios como a poluição e a falta de espaço. Mesmo assim, muitas pessoas se veem obrigadas a migrar para as cidades em busca de oportunidades.');

  // Entrevistas
  createElement('h2', '📌 Entrevistas');
  createP('Entrevista com Agricultor: José Carlos Rodrigues');

  let videoAgricultor = createDiv();
  videoAgricultor.html(`
    <iframe width="400" height="240"
      src="https://www.youtube.com/embed/4cfpXKK5c_I"
      title="Entrevista com Agricultor"
      frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
      allowfullscreen>
    </iframe>
  `);

  // Sugestão da comunidade
  createElement('h2', '💡 Deixe sua sugestão de hábito sustentável:');
  inputSugestao = createInput();
  inputSugestao.attribute('placeholder', 'Escreva aqui...');
  inputSugestao.style('width', '300px');
 
  botaoEnviar = createButton('Enviar');
  botaoEnviar.mousePressed(enviarSugestao);

  createElement('h3', '📋 Sugestões da comunidade:');
}

function enviarSugestao() {
  const texto = inputSugestao.value();
  if (texto.trim() !== '') {
    sugestoes.push(texto);
    createP(`• ${texto}`);
    inputSugestao.value('');
  }
}
